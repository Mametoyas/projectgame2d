extends Node
class_name EnemyFactory

const ENEMY_SCENE: PackedScene = preload("res://asset project/enemy scritp/enemy.tscn")  # ← แก้ path ให้ตรงจริง!
static var DB: Dictionary = preload("res://asset project/enemy scritp/EnemyDB.gd").ENEMY_DB

func _ready() -> void:
	add_to_group("enemy_factory")

func spawn(type_id: String, follower: PathFollow2D) -> Enemy:
	var cfg: Dictionary = DB.get(type_id, {})
	if cfg.is_empty(): return null
	var e: Enemy = ENEMY_SCENE.instantiate() as Enemy   # ← ใช้อันนี้แทน enemy_scene
	e.setup(cfg.merged({"type_id": type_id}))
	e.follower = follower
	return e

# เรียกตอนแตกตัวจาก Enemy.gd (แก้ static ให้ใช้ Engine.get_main_loop())
static func spawn_configured(type_id: String, follower: PathFollow2D) -> Enemy:
	var tree := Engine.get_main_loop() as SceneTree
	if tree == null:
		push_error("SceneTree not available")
		return null
	var fac := tree.get_first_node_in_group("enemy_factory") as EnemyFactory
	if fac == null:
		push_error("EnemyFactory node (group: enemy_factory) not found")
		return null
	return fac.spawn(type_id, follower)
